from products import search_products
from utils import calculate_tax


cart_items = {}


def add_to_cart(user, product_id, quantity):
    if user["id"] not in cart_items:
        cart_items[user["id"]] = []

    cart_items[user["id"]].append({
        "product_id": product_id,
        "quantity": quantity
    })

    print("Product added to cart!")


def calculate_cart_total(user):
    items = cart_items.get(user["id"], [])

    subtotal = 0

    for item in items:
        subtotal += get_item_price(item)

    tax = calculate_tax(subtotal)

    return subtotal + tax


def get_item_price(item):
    products = search_products(str(item["product_id"]))

    if products:
        return products[0]["price"] * item["quantity"]

    return 0


def clear_cart(user):
    cart_items[user["id"]] = []