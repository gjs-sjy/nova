users = [
    {
        "id": 1,
        "username": "alex",
        "password": "password123",
        "email": "alex@example.com"
    }
]

products = [
    {
        "id": 101,
        "name": "Keyboard",
        "price": 50
    },
    {
        "id": 102,
        "name": "Mouse",
        "price": 25
    },
    {
        "id": 103,
        "name": "Monitor",
        "price": 200
    }
]

transactions = []


def get_user(username):
    for user in users:
        if user["username"] == username:
            return user

    return None


def get_all_products():
    return products


def save_transaction(user_id, transaction_id, amount):
    transactions.append({
        "user_id": user_id,
        "transaction_id": transaction_id,
        "amount": amount
    })

    print("Transaction saved!")


def get_transaction_count():
    return len(transactions)


def delete_transaction(transaction_id):
    global transactions

    transactions = [
        t for t in transactions
        if t["transaction_id"] != transaction_id
    ]