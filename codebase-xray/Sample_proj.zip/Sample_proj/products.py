from database import get_all_products
from utils import format_price


def display_products():
    products = get_all_products()

    for product in products:
        print_product(product)


def print_product(product):
    price = format_price(product["price"])

    print("--------------------")
    print(product["name"])
    print(price)


def search_products(keyword):
    products = get_all_products()

    results = []

    for product in products:
        if keyword.lower() in product["name"].lower():
            results.append(product)

    return results


def get_product_count():
    return len(get_all_products())