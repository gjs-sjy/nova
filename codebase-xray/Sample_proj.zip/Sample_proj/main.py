from auth import login
from products import display_products
from cart import add_to_cart, calculate_cart_total
from payment import process_payment


def main():
    print("Welcome to Mini Shop!")

    user = login("alex", "password123")

    if user:
        display_products()

        add_to_cart(user, 101, 2)
        add_to_cart(user, 102, 1)

        total = calculate_cart_total(user)

        process_payment(user, total)


def show_help():
    print("Welcome to the help section!")
    print("Browse products and add them to your cart.")


if __name__ == "__main__":
    main()