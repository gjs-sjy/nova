import random
import string


def format_price(amount):
    return f"${amount:.2f}"


def calculate_tax(amount):
    return amount * 0.08


def generate_transaction_id():
    return "".join(
        random.choices(string.ascii_uppercase + string.digits, k=10)
    )


def calculate_discount(amount, percentage):
    return amount * (percentage / 100)


def format_username(username):
    return username.strip().lower()