from database import save_transaction
from utils import generate_transaction_id, format_price


def process_payment(user, amount):
    transaction_id = generate_transaction_id()

    print("Processing payment...")
    print(f"Amount: {format_price(amount)}")

    success = validate_payment(amount)

    if success:
        save_transaction(user["id"], transaction_id, amount)
        send_receipt(user["email"], transaction_id)

        print("Payment successful!")
        return True

    print("Payment failed!")
    return False


def validate_payment(amount):
    return amount > 0


def send_receipt(email, transaction_id):
    print(f"Receipt sent to {email}")
    print(f"Transaction ID: {transaction_id}")


def refund_payment(transaction_id):
    print(f"Refund issued for {transaction_id}")