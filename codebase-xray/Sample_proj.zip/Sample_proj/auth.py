from database import get_user


def login(username, password):
    user = get_user(username)

    if user and verify_password(password, user["password"]):
        print("Login successful!")
        return user

    print("Login failed!")
    return None


def verify_password(password, stored_password):
    return password == stored_password


def logout(username):
    print(f"{username} has logged out.")


def reset_password(username):
    print(f"Password reset requested for {username}.")